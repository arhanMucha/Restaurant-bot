export const metadata = {
  title: process.env.BUSINESS_NAME || 'Restaurant Bot',
  description: 'AI booking assistant for restaurants',
};

import './globals.css';

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
