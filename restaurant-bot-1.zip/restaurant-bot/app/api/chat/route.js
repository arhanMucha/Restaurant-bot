import { createReservationEvent } from '@/lib/googleCalendar';

const SYSTEM_PROMPT = `You are the front-desk booking assistant for ${process.env.BUSINESS_NAME || 'the restaurant'}.

Business facts:
- Name: ${process.env.BUSINESS_NAME || 'Restaurant'}
- Opening hours: ${process.env.BUSINESS_HOURS || 'Unknown'}
- Address: ${process.env.BUSINESS_ADDRESS || 'Unknown'}
- Phone: ${process.env.BUSINESS_PHONE || 'Unknown'}

Your job:
1. Answer simple guest questions about hours, address, phone, and reservations.
2. Collect reservation details naturally.
3. Required reservation fields: name, partySize, date, time.
4. Optional fields: phone, email, notes.
5. If the user wants a booking but information is missing, ask only for the missing pieces.
6. When enough information exists, set bookingReady to true.
7. Date must be ISO format YYYY-MM-DD and time HH:MM 24-hour format.
8. Never pretend a booking is confirmed if the calendar step has not succeeded.
9. Be warm, brief, clear, and helpful.

Return ONLY valid JSON with this exact shape:
{
  "reply": "message to the guest",
  "intent": "faq" | "reservation" | "other",
  "bookingReady": true | false,
  "booking": {
    "name": string | null,
    "partySize": number | null,
    "date": string | null,
    "time": string | null,
    "phone": string | null,
    "email": string | null,
    "notes": string | null
  }
}`;

function extractJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('No JSON found');
    return JSON.parse(match[0]);
  }
}

async function callAnthropic(messages) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error('Missing ANTHROPIC_API_KEY');
  }

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-3-5-sonnet-latest',
      max_tokens: 500,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: JSON.stringify({ messages })
        }
      ]
    })
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Anthropic error: ${response.status} ${text}`);
  }

  const data = await response.json();
  const text = data?.content?.map((item) => item.text || '').join('\n') || '';
  return extractJson(text);
}

export async function POST(request) {
  try {
    const { messages } = await request.json();
    const ai = await callAnthropic(messages || []);

    let finalReply = ai.reply;
    let confirmed = false;

    if (ai.intent === 'reservation' && ai.bookingReady) {
      const eventResult = await createReservationEvent(ai.booking);

      if (eventResult.ok) {
        confirmed = true;
        finalReply = `Perfect — your table is confirmed for ${ai.booking.partySize} on ${ai.booking.date} at ${ai.booking.time} under the name ${ai.booking.name}. We look forward to welcoming you.`;
      } else {
        finalReply = `${ai.reply}\n\nI have all the details, but calendar connection is not set up yet. Add GOOGLE_REFRESH_TOKEN in Vercel to save bookings automatically.`;
      }
    }

    return Response.json({
      reply: finalReply,
      intent: ai.intent,
      bookingReady: ai.bookingReady,
      booking: ai.booking,
      confirmed,
    });
  } catch (error) {
    return Response.json(
      {
        reply: 'Sorry — something went wrong. Please check your API keys and environment variables.',
        error: error.message,
      },
      { status: 500 }
    );
  }
}
