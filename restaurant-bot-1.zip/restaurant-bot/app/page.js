'use client';

import { useMemo, useState } from 'react';

const starter = `Hi — welcome to ${process.env.NEXT_PUBLIC_BUSINESS_NAME || 'our restaurant'}. I can help with bookings, opening hours, and location. Try: “Table for 2 on Saturday at 19:00”.`;

export default function HomePage() {
  const [messages, setMessages] = useState([
    { role: 'bot', content: starter }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const businessName = process.env.NEXT_PUBLIC_BUSINESS_NAME || 'Trattoria Roma';
  const businessHours = process.env.NEXT_PUBLIC_BUSINESS_HOURS || 'Tue-Sun 12:00-22:00';
  const businessAddress = process.env.NEXT_PUBLIC_BUSINESS_ADDRESS || 'Maximilianstraße 8, Munich';
  const businessPhone = process.env.NEXT_PUBLIC_BUSINESS_PHONE || '+49 89 456789';

  const historyForApi = useMemo(() => messages.map((m) => ({ role: m.role, content: m.content })), [messages]);

  async function sendMessage(e) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || loading) return;

    const nextMessages = [...messages, { role: 'user', content: text }];
    setMessages(nextMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ messages: [...historyForApi, { role: 'user', content: text }] })
      });

      const data = await response.json();
      setMessages((current) => [...current, { role: 'bot', content: data.reply || 'Sorry — no response.' }]);
    } catch {
      setMessages((current) => [...current, { role: 'bot', content: 'Something went wrong. Please check your setup.' }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="page">
      <section className="left">
        <div className="brand">
          <span className="badge">24/7 Reservation Assistant</span>
        </div>
        <h1>{businessName}</h1>
        <p className="subtitle">
          A simple AI host that answers guest questions, collects reservations, and can write bookings straight into Google Calendar.
        </p>

        <div className="info-grid">
          <div className="info-card">
            <div className="info-label">Opening Hours</div>
            <div className="info-value">{businessHours}</div>
          </div>
          <div className="info-card">
            <div className="info-label">Phone</div>
            <div className="info-value">{businessPhone}</div>
          </div>
          <div className="info-card">
            <div className="info-label">Address</div>
            <div className="info-value">{businessAddress}</div>
          </div>
          <div className="info-card">
            <div className="info-label">What it can do</div>
            <div className="info-value">Take reservations, answer FAQs, and collect contact details for your team.</div>
          </div>
        </div>
      </section>

      <section className="right">
        <div className="chat-shell">
          <div className="chat-header">
            <div className="chat-title">Chat with {businessName}</div>
            <div className="chat-subtitle">Ask about bookings, opening hours, address, or phone.</div>
          </div>

          <div className="messages">
            {messages.map((message, index) => (
              <div key={index} className={`message ${message.role === 'user' ? 'user' : 'bot'}`}>
                {message.content}
              </div>
            ))}
          </div>

          <div className="status">{loading ? 'Assistant is typing...' : 'Ready'}</div>

          <form className="composer" onSubmit={sendMessage}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
            />
            <button type="submit">Send</button>
          </form>
        </div>
      </section>
    </main>
  );
}
