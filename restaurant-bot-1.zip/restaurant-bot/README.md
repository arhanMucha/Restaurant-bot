# Restaurant Bot

A simple Next.js starter for a restaurant booking assistant.

## What it does
- answers guest questions with Anthropic
- collects reservation details
- writes bookings into Google Calendar when `GOOGLE_REFRESH_TOKEN` is set
- deploys easily on Vercel

## 1. Vercel environment variables
Add these in Vercel:

```bash
ANTHROPIC_API_KEY=your_anthropic_key
BUSINESS_NAME=Trattoria Roma
BUSINESS_HOURS=Tue-Sun 12:00-22:00
BUSINESS_ADDRESS=Maximilianstraße 8, Munich
BUSINESS_PHONE=+49 89 456789
GOOGLE_CALENDAR_ID=primary
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GOOGLE_REFRESH_TOKEN=your_google_refresh_token
TIMEZONE=Europe/Berlin
NEXT_PUBLIC_BUSINESS_NAME=Trattoria Roma
NEXT_PUBLIC_BUSINESS_HOURS=Tue-Sun 12:00-22:00
NEXT_PUBLIC_BUSINESS_ADDRESS=Maximilianstraße 8, Munich
NEXT_PUBLIC_BUSINESS_PHONE=+49 89 456789
```

## 2. Local development
```bash
npm install
npm run dev
```

## 3. Deploy to Vercel
- create a new Vercel project
- upload this folder or push it to GitHub and import it
- add the environment variables above
- deploy

## 4. About Google Calendar
This starter uses a refresh token already stored in environment variables.
That is simpler than building a full “Connect Calendar” login flow on day 1.

If you do not set `GOOGLE_REFRESH_TOKEN`, the bot still chats and collects booking details, but it will tell you that automatic calendar saving is not connected yet.
